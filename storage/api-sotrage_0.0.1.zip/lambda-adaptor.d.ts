import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda/trigger/api-gateway-proxy";
export declare const getUploadSignedUrl: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getDownloadSignedUrl: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
