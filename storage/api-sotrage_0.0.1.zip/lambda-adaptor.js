"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDownloadSignedUrl = exports.getUploadSignedUrl = void 0;
const getUploadSignedUrl = async (event) => {
    const queries = JSON.stringify(event.queryStringParameters);
    return {
        statusCode: 200,
        body: `Queries: ${queries}`
    };
};
exports.getUploadSignedUrl = getUploadSignedUrl;
const getDownloadSignedUrl = async (event) => {
    const queries = JSON.stringify(event.queryStringParameters);
    return {
        statusCode: 200,
        body: `Queries: ${queries}`
    };
};
exports.getDownloadSignedUrl = getDownloadSignedUrl;
